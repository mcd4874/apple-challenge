var express = require('express');
var app = express.Router();
var mysql = require('mysql');

var connection = mysql.createConnection({
  host: 'localhost', // hh.nickrung.me localhost
  user: 'root',
  password: 'devpass1'
});

connection.connect();

connection.query('USE 3guys1app');

// ===============
// === WEBSITE ===
// ===============

/* GET home page. */
app.get('/', function(req, res, next) {
  res.render('index', { title: 'MeetMe' });
});

app.post('/', function(req, res){

  if(req.body.username === "nrung") {
    console.log("Yes");
    res.redirect('/map');
  } else {
    console.log("Yes");
    res.redirect('/');
  }
});

app.get('/map', function(req, res, next) {
  var un = "nrung";
  var lats = [];
  var longs = [];
  var names = [];
  var titles = [];
  var hours = [];

  connection.query('SELECT * FROM locations', ["nrung"], function(err, rows) {

    for(var i=0; i<rows.length; i++) {

      lats.push(rows[i].lat);
      longs.push(rows[i].lon);
      names.push(rows[i].user);
      titles.push(rows[i].title);
      hours.push(rows[i].hours);
      console.log(hours[i]);
    }

  res.render('map', {
    title: 'MeetMe',
    lats: lats,
    longs: longs,
    names: names,
    titles: titles,
    hours: hours,
    time : new Date().toString()
  });
  });
});

app.get('/propic', function(req, res) {
  res.sendfile('../nick.png');
});

app.get('/signup', function(req, res){

   res.render('signup', {title: 'MeetMe'}) ;
});

//app.post('/signup', function(req, res, next){
//
//});


// Auth user
//

// ===============
// ===== API =====
// ===============

// GET home page.
app.get('/api', function(req, res, next) {
  res.render('map', { title: 'Express' });
});

app.post('/api/', function(req, res){

  console.log(req.body);
  res.send(JSON.stringify({"confirmation":"WE GOOD, FAM!"}));
});

app.post('/api/login', function(req, res){
  console.log(req.body);
  res.send(JSON.stringify({"secretcode":"OKFAM"}));

});

app.get('/api/map', function(req, res, next) {
  console.log("THIS IS A GET" + JSON.parse(req.body));

  connection.query('SELECT * FROM locations', [], function (err, rows) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
    console.log("ROWS SENT!!!")
  });

});

app.post('/api/map', function(req, res, next) {
  console.log("THIS IS A POST" + JSON.parse(req.body));
  console.log(req.body.lat);
  var d = JSON.parse(req.body);

  connection.query('INSERT INTO locations (lat, lon, title, hours, user) VALUES (?,?,?,?,?)', [d.lat, d.lon, d.title, d.time, d.username], function (err, rows) {
    if (err) throw err;
    res.send("==== OK ====");
    console.log("OK SENT")
  });

});

module.exports = app;